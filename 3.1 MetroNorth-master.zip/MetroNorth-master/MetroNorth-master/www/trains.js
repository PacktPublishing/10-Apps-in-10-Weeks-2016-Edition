var xmlhttp;
var stationNumber;
var blank = '<ul id="trainSchedWest" data-role="listview"><li data-role="list-divider">Westbound</li></ul><ul id="trainSchedEast" data-role="listview"><li data-role="list-divider">Eastbound</li></ul>';

window.onload=function()
{
//    document.addEventListener('deviceready', init, false);
    init();
}

function init()
{
    document.getElementById('btnNext').addEventListener('click', getTrains, false);
    xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = processResult;
    populateStations();
    if(localStorage.stationChoice)
        {
            stationNumber = localStorage.getItem("stationChoice");
            $("#select-station").val(stationNumber).selectmenu("refresh");
        }
    document.getElementById('select-station').addEventListener('change', function(){
        stationNumber = document.getElementById('select-station').value;
        localStorage.setItem("stationChoice", stationNumber);
    }, false);
}

function populateStations()
{
    var out="";
    
    for(x in stations)
        {
            out += "<option value='" + x + "'>" + stations[x] + "</option>";
            
        }
    document.getElementById('select-station').innerHTML = out;
}

function getTrains()
{
    xmlhttp.open("GET", "https://mnorth.prod.acquia-sites.com/wse/gtfsrtwebapi/v1/gtfsrt/" + key + "/getfeed", true);
    xmlhttp.send();   
}

function processResult()
{
    if(xmlhttp.readyState==4 && xmlhttp.status==200)
    {
        //alert("Selected Station:" + stations[stationNumber]);
        document.getElementById('schedules').innerHTML = blank;
        var result = jQuery.parseJSON(xmlhttp.responseText);
        console.log(result);
        for(var x=0; x < result.entity.length; x++)
        {
            var trainNumber = result.entity[x].id;
            var stops = result.entity[x].trip_update.stop_time_update;
            
            if(stops != null && stops != "")
            {
                //Loop through stops to see if it stops in Selected Town
                //
                for(var y =0; y < stops.length; y++)
                {
                    //These Trains Stop at selected station
                    if(stops[y].stop_id == stationNumber)
                    {
                        //Calculate Departure Time
                        var epTime = stops[y].departure.time
                        var departTime = new Date(0);
                        departTime.setUTCSeconds(epTime);
                        var hours = departTime.getHours();
                        if(hours > 12)
                        {
                            hours -= 12;   
                        }
                        
                        var mins = departTime.getMinutes()
                        if (mins < 10)
                        {
                            mins = "0" + mins;
                        } 
                        
                        departTime = hours + ":" + mins;
                        
                        //Where is the train coming from and going?
                        var origin = stops[0].stop_id;
                        var dest = stops[stops.length-1].stop_id;
                        var direction;
                        if(dest > origin)
                        {
                            direction = "Eastbound";   
                        } else
                        {
                            direction = "Westbound";   
                        }
                        dest = stations[dest];
                        createOutput(trainNumber, departTime, dest, direction);
                        refreshLists();
                        
                    }
                    }
                }
            }
        }
            
}
        
function refreshLists()
{
    populateStations();
    $("#trainSchedWest").listview().listview('refresh'); 
    $("#trainSchedEast").listview().listview('refresh');
    $("#select-station").attr('selectedIndex', stationNumber);
}

function createOutput(trainNum, departTime, dest, direction)
{
    
    if(direction == "Westbound")
    {
        var out = "<li><strong>"+ departTime + "</strong> Final Stop: <strong>" + dest + "</strong><br/>";
        out += "<span class='small'>Train Number: " + trainNum + "</li>";
        document.getElementById('trainSchedWest').innerHTML += out;
    } else
    {
    
        var out = "<li><strong>"+ departTime + "</strong> Final Stop: <strong>" + dest + "</strong><br/>";
        out += "<span class='small'>Train Number: " + trainNum + "</li>";
        document.getElementById('trainSchedEast').innerHTML += out;
    }
}
