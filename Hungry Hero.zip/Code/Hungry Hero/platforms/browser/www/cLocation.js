var cLocation = function(lat,long){
    this.lat = lat;
    this.long = long;
}